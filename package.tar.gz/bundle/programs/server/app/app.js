var require = meteorInstall({"both":{"routes":{"authenticated.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// both/routes/authenticated.js                                                                    //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"configure.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// both/routes/configure.js                                                                        //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"public.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// both/routes/public.js                                                                           //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
FlowRouter.route('/', {                                                                            // 1
  action: function action(params, queryParams) {                                                   // 2
    BlazeLayout.render('home');                                                                    // 3
  }                                                                                                // 4
});                                                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"dataStore.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/dataStore.js                                                                             //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":["meteor/meteor","assert","uuid","lokijs","clean-this-tweet-up",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/methods.js                                                                               //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                        // 1
var assert = require('assert');                                                                    // 2
var uuid = require("uuid");                                                                        // 3
var loki = require('lokijs');                                                                      // 4
// init in mem db                                                                                  //
var memDb = new loki('userdb');                                                                    // 6
// global user object                                                                              //
user = memDb.addCollection('user', { indices: ['username'] });                                     // 8
                                                                                                   //
Meteor.startup(function () {                                                                       // 10
                                                                                                   //
  var Future = Npm.require('fibers/future');                                                       // 12
  var getResult = function getResult(result) {                                                     // 13
    return result;                                                                                 // 14
  };                                                                                               // 15
  Meteor.methods({                                                                                 // 16
                                                                                                   //
    getTweets: function getTweets(query) {                                                         // 18
      check(query, String);                                                                        // 19
      var future = new Future();                                                                   // 20
      // https://github.com/ttezel/twit                                                            //
      var Twitter = new Twit({                                                                     // 22
        consumer_key: Meteor.settings['private'].twitter.consumerKey,                              // 23
        consumer_secret: Meteor.settings['private'].twitter.consumerSecret,                        // 24
        access_token: Meteor.settings['private'].twitter.accessToken,                              // 25
        access_token_secret: Meteor.settings['private'].twitter.accessTokenSecret                  // 26
      });                                                                                          // 22
      // get tweets                                                                                //
      Twitter.get('statuses/user_timeline',                                                        // 29
      // params for twitter api call                                                               //
      { screen_name: query, count: 20 },                                                           // 31
      // callback                                                                                  //
      function (error, data, response) {                                                           // 33
        if (error) future['return'](error);                                                        // 34
        var tweetVals = [];                                                                        // 35
        // format tweet text                                                                       //
        data.forEach(function (dat) {                                                              // 37
          if (!dat.text) return;                                                                   // 38
                                                                                                   //
          // filter out unreadable words for sentiment analysis                                    //
          // remove special characters & remove entirely any words that have 'htt' in them (links)
          var tweetObj = {};                                                                       // 42
          tweetObj.text = dat.text;                                                                // 43
                                                                                                   //
          if (dat.entities) {                                                                      // 45
            tweetObj.entities = dat.entities;                                                      // 46
          };                                                                                       // 47
                                                                                                   //
          var cleanThisTweet = require('clean-this-tweet-up');                                     // 49
          tweetObj = cleanThisTweet(tweetObj);                                                     // 50
                                                                                                   //
          if (tweetObj.entities) {                                                                 // 52
            delete tweetObj.entities;                                                              // 53
          }                                                                                        // 54
          tweetObj = tweetObj.replace(/[^a-zA-Z ]/g, " ").replace(/ *\b\S*?htt\S*\b/g, " ");       // 55
          // remove entities after using them in cleanThisTweet https://github.com/coleww/clean-this-tweet-up/blob/master/test.js#L7-L16
          // format the sentiment api call text used later in getSentiments                        //
          var apiBaseUrl = 'http://api.datumbox.com/1.0/TwitterSentimentAnalysis.json?api_key=';   // 60
          var apiKey = Meteor.settings['private'].sentiment.apiKey;                                // 61
          var sentimentUrl = apiBaseUrl + apiKey + tweetObj;                                       // 62
          var profImage = dat.user.profile_image_url;                                              // 63
          // create object for rendering results while we call the sentiment api                   //
          var tweetVal = {                                                                         // 65
            'text': tweetObj,                                                                      // 66
            'sentiment': '',                                                                       // 67
            'id_str': dat.id_str,                                                                  // 68
            'profImage': profImage,                                                                // 69
            'sentimentUrl': sentimentUrl                                                           // 70
          };                                                                                       // 65
          tweetVals.push(tweetVal);                                                                // 72
        });                                                                                        // 73
        // create tweet obj with formatted text                                                    //
        var tweetObj = {                                                                           // 75
          id: uuid(),                                                                              // 76
          username: query,                                                                         // 77
          tweets: tweetVals                                                                        // 78
        };                                                                                         // 75
        // save into memory (not doing anything w/ this yet)                                       //
        user.insert(tweetObj);                                                                     // 81
        future['return'](tweetObj);                                                                // 82
      });                                                                                          // 83
      // end of get tweets callback, wait until all tweets are formatted                           //
      return future.wait();                                                                        // 85
    },                                                                                             // 86
    getSentiments: function getSentiments(tweets) {                                                // 87
      var urls = [];                                                                               // 88
      tweets.tweets.forEach(function (tweet) {                                                     // 89
        urls.push(tweet.sentimentUrl);                                                             // 90
      });                                                                                          // 91
      // Keep track of each job in an array                                                        //
      var futures = _.map(urls, function (url) {                                                   // 93
        // Set up a future for the current job                                                     //
        var future = new Future();                                                                 // 95
        // A callback so the job can signal completion                                             //
        var onComplete = future.resolver();                                                        // 97
        // Make async http call                                                                    //
        HTTP.call("POST", url, function (error, result) {                                          // 99
          // Get the result if there was no error                                                  //
          var title = !error && getResult(result);                                                 // 101
          // Inform the future that we're done with it                                             //
          onComplete(error, title);                                                                // 103
        });                                                                                        // 104
        // Return the future                                                                       //
        return future;                                                                             // 106
      });                                                                                          // 107
      // wait for all futures to finish                                                            //
      Future.wait(futures);                                                                        // 109
      // and grab the results out.                                                                 //
      return _.invoke(futures, 'get');                                                             // 111
    }                                                                                              // 112
  });                                                                                              // 16
});                                                                                                // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////

}],"startup.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/startup.js                                                                               //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
Meteor.startup(function () {});                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},"timelines.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// timelines.js                                                                                    //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
// media tweet handle                                                                              //
                                                                                                   //
/*                                                                                                 //
var T = new Twit(config)                                                                           //
                                                                                                   //
Create a Twit instance that can be used to make requests to Twitter's APIs.                        //
                                                                                                   //
If authenticating with user context, config should be an object of the form:                       //
                                                                                                   //
{                                                                                                  //
  consumer_key:         '...'                                                                      //
    , consumer_secret:      '...'                                                                  //
  , access_token:         '...'                                                                    //
  , access_token_secret:  '...'                                                                    //
}                                                                                                  //
If authenticating with application context, config should be an object of the form:                //
                                                                                                   //
{                                                                                                  //
  consumer_key:         '...'                                                                      //
    , consumer_secret:      '...'                                                                  //
  , app_only_auth:        true                                                                     //
}                                                                                                  //
Note that Application-only auth will not allow you to perform requests to API endpoints requiring a user context, such as posting tweets. However, the endpoints available can have a higher rate limit.
                                                                                                   //
                                                                                                   //
                                                                                                   //
  import tweepy #https://github.com/tweepy/tweepy                                                  //
  import csv                                                                                       //
                                                                                                   //
#Twitter API credentials                                                                           //
consumer_key = ""                                                                                  //
consumer_secret = ""                                                                               //
access_key = ""                                                                                    //
access_secret = ""                                                                                 //
                                                                                                   //
                                                                                                   //
def get_all_tweets(screen_name):                                                                   //
#Twitter only allows access to a users most recent 3240 tweets with this method                    //
                                                                                                   //
#authorize twitter, initialize tweepy                                                              //
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)                                          //
auth.set_access_token(access_key, access_secret)                                                   //
api = tweepy.API(auth)                                                                             //
                                                                                                   //
#initialize a list to hold all the tweepy Tweets                                                   //
alltweets = []                                                                                     //
                                                                                                   //
#make initial request for most recent tweets (200 is the maximum allowed count)                    //
new_tweets = api.user_timeline(screen_name = screen_name,count=200)                                //
                                                                                                   //
#save most recent tweets                                                                           //
alltweets.extend(new_tweets)                                                                       //
                                                                                                   //
#save the id of the oldest tweet less one                                                          //
oldest = alltweets[-1].id - 1                                                                      //
                                                                                                   //
#keep grabbing tweets until there are no tweets left to grab                                       //
while len(new_tweets) > 0:                                                                         //
print ("getting tweets before %s" % (oldest))                                                      //
                                                                                                   //
#all subsiquent requests use the max_id param to prevent duplicates                                //
new_tweets = api.user_timeline(screen_name = screen_name,count=200,max_id=oldest)                  //
                                                                                                   //
#save most recent tweets                                                                           //
alltweets.extend(new_tweets)                                                                       //
                                                                                                   //
#update the id of the oldest tweet less one                                                        //
oldest = alltweets[-1].id - 1                                                                      //
                                                                                                   //
print ("...%s tweets downloaded so far" % (len(alltweets)))                                        //
                                                                                                   //
#transform the tweepy tweets into a 2D array that will populate the csv                            //
outtweets = [[tweet.id_str, tweet.created_at, tweet.text.encode("utf-8")] for tweet in alltweets]  //
                                                                                                   //
#write the csv                                                                                     //
with open('%s_tweets.csv' % screen_name, 'w') as f:                                                //
writer = csv.writer(f)                                                                             //
writer.writerow(["id","created_at","text"])                                                        //
writer.writerows(outtweets)                                                                        //
                                                                                                   //
pass                                                                                               //
                                                                                                   //
                                                                                                   //
if __name__ == '__main__':                                                                         //
#pass in the username of the account you want to download                                          //
get_all_tweets("J_tsar")                                                                           //
                                                                                                   //
*/                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./both/routes/authenticated.js");
require("./both/routes/configure.js");
require("./both/routes/public.js");
require("./server/dataStore.js");
require("./server/methods.js");
require("./server/startup.js");
require("./timelines.js");
//# sourceMappingURL=app.js.map
